# CountMe.

 
A simple java application that allows the user to increase and decrease the value of the counter by one or by ten and give the option to reset value to 0.


## Description.


The user displays 0 as the value of the counter and has five buttons +/- +10/-10 and "reset" to change the value of the counter.

The counter layout is minimalistic and clean.


## Link.

[https://countmecof.netlify.app/](https://countmecof.netlify.app/)


## Author.

Andrea Coffetti.

[https://twitter.com/andrea_coffetti](https://twitter.com/andrea_coffetti).
[https://github.com/CofAndrea](https://github.com/CofAndrea).

Version History.
0.1.
Initial Release.